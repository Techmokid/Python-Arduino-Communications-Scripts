#ifndef Button_h
#define Button_h
#include "Arduino.h"

class Python {
	public:
		void writeLine(String dataToWrite);
		String readLine();
	private:
		
};

#endif